# impressingCrush
link mobile.js instead of script.js in index.html to work in mobile.

Thanks and Happy Coding.
